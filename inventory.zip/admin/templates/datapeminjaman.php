<?php
include('../connect.php');
// $url = $_SERVER['REQUEST_URI'];
// echo '<META HTTP-EQUIV="Refresh" Content="5"; URL="$url">';
?>

<head>
    <!-- Modal Request -->
    <div id="Modal_request" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <!-- <h4 class="modal-title">Request Barang</h4> -->
                </div>
                <div class="modal-body">
                    <?php
                    $sql = mysqli_query($connect, "SELECT * FROM transaksi WHERE transaksi='Pinjam'");
                    ?>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>NAMA PEMINJAM</th>
                                <th>NAMA ITEM / ID</th>
                                <th>WAKTU REQUEST</th>
                                <th></th>
                            </tr>
                        </thead>
                        <?php
                        while ($data = mysqli_fetch_array($sql)) {
                            $Anggota = $data['namaanggota'];
                            $Id_item = $data['iditem'];
                            $Item = $data['namaitem'];
                            $DateTime = $data['datetime'];
                        ?>
                            <tbody>
                                <tr>
                                    <td><?php echo $Anggota; ?></td>
                                    <td><?php echo $Item; ?></td>
                                    <td><?php echo $DateTime; ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <!-- data-toggle="modal" data-dismiss="modal" data-target="#Modal_open_loker"  -->
                                            <!-- href="loker.php?v=<?php echo $loker; ?>&s=open" -->
                                            <!-- href="?page=approve&id=<?php echo $Id_item; ?>&n=<?php echo $Anggota; ?>" -->
                                            <a class="btn btn-success btn-sm" role="button" href="?p=approve&trns=pinjam&id=<?php echo $Id_item; ?>&n=<?php echo $Anggota; ?>">
                                                <i class="fa fa-check fa-mini"></i></a>
                                            <a class="btn btn-danger btn-sm" href="hapusdata.php?data=pinjam&id=<?php echo $Id_item; ?>" role="button">
                                                <i class="fa fa-trash fa-mini"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php
                        }
                            ?>
                            </tbody>
                    </table>
                    <br>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</head>

<body>
    <?php
    $sql = mysqli_query($connect, "SELECT COUNT('transaksi') AS totaldata FROM transaksi WHERE transaksi='Pinjam'");
    $x = mysqli_fetch_array($sql);
    $total_request = $x['totaldata'];
    ?>
    <br><br><br>
    <div>
        <h2 style="margin-top:10px;color:#666666;text-align:center;margin:20px;">DATA PEMINJAMAN</h2>
    </div>

    <div class="container" style="overflow-y:none; overflow-x:none; min-height:270px">
        <div class="center" style="margin-top:30px;">
            <div class="text-left">
                <div class="btn-group">
                    <a class="btn btn-success btn-md" href="exportexcel.php?data=pinjam">
                        <i class="fa fa-file-excel-o fa-md"> Export to Excel</i></a>
                </div>

                <div class="btn-group">
                    <a type="button" class="btn btn-primary btn-md" data-toggle="modal" <?php if ($total_request > 0) { ?> data-target="#Modal_request" <?php } ?>>
                        Request&nbsp;<span class="badge"><?php echo $total_request; ?></span></a>
                    <a class="btn btn-default btn-md" onclick="location.reload();">
                        <i class="fa fa-refresh fa-md"></i></a>
                </div>
            </div>

            <br><br>
            <table id="table_id" class="table table-hover" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>NAMA ITEM / ID</th>
                        <th>LOKER</th>
                        <th>NAMA PEMINJAM</th>
                        <th>NAMA STAF</th>
                        <th>DIKEMBALIKAN</th>
                        <th>WAKTU TRANSAKSI</th>
                        <!-- <th></th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $sql_b = mysqli_query($connect, "SELECT * FROM datapinjam ORDER BY no ASC");
                    while ($data = mysqli_fetch_array($sql_b)) {
                        // $Judul = $data['judul'];
                        // $tglakhir = $data['tanggalkembali'];
                        // $tglnow = date('Y-m-d');
                        // //$totalhari = IntervalDays($tglakhir, $tglnow);
                        // if (strtotime($tglnow) > strtotime($tglakhir)) $totalhari = ((abs(strtotime($tglnow) - strtotime($tglakhir))) / (60 * 60 * 24));
                        // else $totalhari  = 0;
                        // if ($totalhari < 0) $totalhari = 0;
                        // $totalBayar = $denda * $totalhari;
                        // $query = "UPDATE datapinjam SET status='$totalhari', denda='$totalBayar' WHERE tanggalkembali='$tglakhir' AND judul='$Judul'";
                        // $sql = mysqli_query($connect, $query);
                    ?>
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo $data['namaitem']; ?></td>
                            <td><?php echo $data['loker']; ?></td>
                            <td><?php echo $data['namaanggota']; ?></td>
                            <td><?php echo $data['namastaf']; ?></td>
                            <td><?php echo $data['status']; ?></td>
                            <td><?php echo $data['datetime']; ?></td>
                            <!-- <td><?php echo $data['time']; ?></td> -->
                            <?php
                            // if ($totalhari != 0) {
                            ?>
                            <!-- <td style="color:red"> Terlambat <?php echo $totalhari; ?> hari denda Rp <?php echo $totalBayar; ?></td> -->
                            <?php
                            // } else {
                            ?>
                            <!-- <td> Terlambat <?php echo $totalhari; ?> hari denda Rp <?php echo $totalBayar; ?></td> -->
                            <?php
                            // }
                            ?>

                            <!-- <td>
                            <a href="../?page=kembali" class="btn btn-info btn-mini" role="button" aria-pressed="true">
                                <i class="fa fa-inbox fa-mini"></i></a>
                            <a href="../?page=perpanjang" class="btn btn-warning btn-mini" role="button" aria-pressed="true">
                                <i class="fa fa-calendar-plus-o fa-mini"></i></a>
                        </td> -->
                        </tr>
                    <?php $no++;
                    } ?>
                </tbody>
                <tfooter>
                    <th>NO</th>
                    <th>NAMA ITEM / ID</th>
                    <th>LOKER</th>
                    <th>NAMA PEMINJAM</th>
                    <th>NAMA STAF</th>
                    <th>DIKEMBALIKAN</th>
                    <th>WAKTU TRANSAKSI</th>
                    <!-- <th></th> -->
                    </tr>
                </tfooter>
            </table>
            <br>
        </div>
    </div>
</body>