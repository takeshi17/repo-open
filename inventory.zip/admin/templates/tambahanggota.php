<?php
include("../connect.php");
?>

<?php
date_default_timezone_set('Asia/Jakarta');
$datetime = date('Y-m-d H:i:s');

// CEK ID YANG BELUM DIGUNAKAN
$min_id = 1;
$max_id = 127;
for ($i = $min_id; $i <= $max_id; $i++) {
    $row = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM dataanggota WHERE id='$i'"));
    $cek_ID = $row["id"];

    if ($i != $cek_ID) {
        $last_id = $i;
        break;
    }
}

// SET MODE ENROLL
$result = mysqli_query($connect, "SELECT * FROM receivedata WHERE variabel='finger'");
$row = mysqli_fetch_array($result);
$cek = $row["value"];
$status = $row["status"];

if ($status == "enrolled") $cycle_cek = true;
else $cycle_cek = false;

if ($cycle_cek == false) {
    $url = $_SERVER['REQUEST_URI'];
    echo '<META HTTP-EQUIV="Refresh" Content="3"; URL="$url">';
}

if ($cek == "") $sql = "INSERT into receivedata (variabel, value, mode, status) VALUES ('finger', '$last_id', 'enroll', '-')";
else $sql = "UPDATE receivedata SET value='$last_id', mode='enroll', status='-' WHERE variabel='finger'";

if (!mysqli_query($connect, $sql)) {
    echo "Error: " . $sql . "<br>" . mysqli_error($connect);
}


if (isset($_SESSION['username'])) {
?>
    <div class="container">
        <br><br><br>
        <center>
            <h2>REGISTRASI ANGGOTA</h2>
        </center>
        <br>

        <center>
            <?php
            if ($status != "enrolled") {
            ?>
                <h6>SILAHKAN SCAN JARI HINGGA PROSES ENROLL SUKSES</h6>
            <?php  } else {
            ?>
                <h6>SILAHKAN ISI NAMA DAN STATUS</h6>
                <h6>LALU TEKAN TAMBAHKAN</h6>
            <?php
            }
            ?>
            <button class="btn btn-default btn-md" type="button" onclick="<?php mysqli_query($connect, "UPDATE receivedata SET status='-' WHERE variabel='enroll'") ?>; location.reload();">
                RESET
            </button>
        </center>
        <br><br>

        <form action="" method="post">
            <div class="form-group">
                <label name="id">ID</label>
                <input autocomplete="off" class="form-control" placeholder="ID" type="text" name="id" value="<?php echo $last_id; ?>" readonly required>
            </div>

            <?php
            if ($status == "enrolled") {
            ?>
                <div class="form-group">
                    <label name="username">Nama</label>
                    <input autocomplete="off" class="form-control" placeholder="Isi Nama" type="text" name="nama" required>

                    <br>
                    <label name="id">Status Anggota</label>
                    <select id="status" class="form-control" type="text" name="status" required>
                        <option value="Umum">Umum</option>
                        <option value="Staf">Staf</option>
                    </select>
                </div>

                <br><br>
                <center>
                    <div>
                        <button class="btn btn-primary btn-block" type="submit" name="submit" value="">
                            TAMBAHKAN
                        </button>
                    </div>
                </center>

                <br>
                <center>
                    <div>
                        <button class="btn btn-success btn-block" type="button" onclick="location='?p=dataanggota'">
                            BATAL
                        </button>
                    </div>
                </center>
            <?php
            } else {
            ?>
                <br>
                <center>
                    <div>
                        <button class="btn btn-success btn-block" type="button" onclick="location='?p=dataanggota'">
                            SELESAI
                        </button>
                    </div>
                </center>
            <?php
            }
            ?>
        </form>
    </div>

<?php
    $result = mysqli_query($connect, "SELECT * FROM dataanggota ORDER BY No DESC LIMIT 1");
    $row = mysqli_fetch_array($result);
    $last_no = $row["no"];

    if (isset($_POST['submit'])) {
        $last_no++;
        $ID = $_POST['id'];
        $Nama = $_POST['nama'];
        $Status = $_POST['status'];

        $sql = "INSERT INTO `dataanggota` (no, id, nama, status, datetime) VALUES ('$last_no','$ID', '$Nama', '$Status', '{$datetime}')";
        $sql = mysqli_query($connect, $sql);
        if ($sql) {
            echo "<script>alert('Berhasil menambah anggota..');location='?p=tambahanggota'</script>";
            $sql = "UPDATE receivedata SET status='-' WHERE variabel='enroll'";
            if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        } else {
            echo "<script>alert('Gagal! Coba lagi..');location='?p=tambahanggota'</script>";
            $sql = "UPDATE receivedata SET status='-' WHERE variabel='enroll'";
            if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        }
    }
}
?>
<br><br>