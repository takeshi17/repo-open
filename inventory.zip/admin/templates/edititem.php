<?php
include("../connect.php");
?>

<?php
date_default_timezone_set('Asia/Jakarta');
$datetime = date('Y-m-d H:i:s');

if (isset($_GET['id'])) {
    $Select_id = $_GET['id'];
    $ID = rawurldecode($Select_id);

    $result = mysqli_query($connect, "SELECT * FROM dataitem WHERE id='$ID'");
    while ($data = mysqli_fetch_array($result)) {
?>
        <div class="container">
            <br><br><br>
            <center>
                <h2>EDIT ITEM</h2>
            </center>
            <br>

            <form action="" method="post">
                <div class="form-group">
                    <label name="namaitem">Nama item</label>
                    <input autocomplete="off" class="form-control" placeholder="Isi Nama" type="text" name="namaitem" value="<?php echo $data["namaitem"]; ?>" required>

                    <br>
                    <label name="loker">Loker</label>
                    <?php
                    $sql = mysqli_query($connect, "SELECT * FROM loker ORDER BY variabel ASC");
                    if (mysqli_num_rows($sql) > 0) {
                    ?>
                        <select id="loker" type="text" class="form-control" name="loker">
                            <?php
                            while ($data = mysqli_fetch_array($sql)) {
                            ?>
                                <option value=<?php echo $data['variabel']; ?>><?php echo $data['variabel']; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    <?php
                    }
                    ?>

                    <br><br>
                    <center>
                        <div>
                            <button class="btn btn-primary btn-block" type="submit" name="submit">
                                SIMPAN
                            </button>

                            <br>
                            <button class="btn btn-warning btn-block" type="button" onclick="location='?p=dataitem'">
                                BATAL
                            </button>
                        </div>
                    </center>
            </form>
        </div>

<?php
    }

    if (isset($_POST['submit'])) {
        $Nama = $_POST['namaitem'];
        $Loker = $_POST['loker'];

        $sql = mysqli_query($connect, "UPDATE dataitem SET namaitem='$Nama', loker='$Loker' WHERE id='$ID'");
        if ($sql) {
            echo "<script> location='?p=dataitem'</script>";
            $sql = "UPDATE receivedata SET status='-' WHERE value='-'";
            if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        } else {
            echo "<script>alert('Gagal mengedit data!');</script>";
            $sql = "UPDATE receivedata SET status='-' WHERE value='-'";
            if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        }
    }
}
?>
<br> <br> <br>