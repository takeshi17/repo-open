<?php
include('../connect.php');
//$url=$_SERVER['REQUEST_URI'];
//echo '<META HTTP-EQUIV="Refresh" Content="5"; URL="$url">';
?>

<head>

</head>

<body>
	<br><br><br>
	<div>
		<h2 style="margin-top:10px;color:#666666;text-align:center;margin:20px;">DATA &nbsp;ITEM</h2>
	</div>

	<div class="container" style="overflow-y:none; overflow-x:none; min-height:270px">
		<div class="center" style="margin-top:30px;">
			<div class="text-left">
				<div class="btn-group">
					<a class="btn btn-primary btn-md" href="?p=tambahitem&items=&loker=">
						<i class="fa fa-plus-square fa-md"> Tambah Item</i></a>
					<a class="btn btn-success btn-mini" href="exportexcel.php?data=items">
						<i class="fa fa-file-excel-o fa-mini"> Export to Excel</i></a>
				</div>
			</div>

			<br><br>
			<table id="table_id" class="table table-hover">
				<thead>
					<tr valign="middle">
						<th>NO</th>
						<th>NAMA ITEM / ID</th>
						<th>LOKER</th>
						<th>STATUS</th>
						<th> </th>
					</tr>
				</thead>
				<tbody>
					<?php
					$no = 0;
					$sql = mysqli_query($connect, "SELECT * FROM dataitem");
					while ($data = mysqli_fetch_array($sql)) {
						$no++;
						$id = $data['id'];
						$nama_item = $data['namaitem'];
						$loker = $data['loker'];
						$status = $data['status'];
						$nama_id = $nama_item . " [" . $id . " ]";
					?>
						<tr>
							<td><?php echo $no; ?></td>
							<td><?php echo $nama_item . " [" . $id . " ]"; ?></td>
							<td><?php echo $loker; ?></td>
							<td><?php echo $status; ?></td>
							<td align="center">
								<div class="btn-group">
									<a href="?p=edititem&id=<?php echo $id; ?>" class="btn btn-warning btn-sm <?php if ($status == "Dipinjam" || $status == "Waiting for approval") { ?>disabled<?php } else { ?>active<?php } ?>" role="button">
										<i class="fa fa-pencil-square-o fa-mini"></i></a>
									<a href="hapusdata.php?data=item&id=<?php echo $id; ?>" class="btn btn-danger btn-sm <?php if ($status == "Dipinjam" || $status == "Waiting for approval") { ?>disabled<?php } else { ?>active<?php } ?>" role="button">
										<i class="fa fa-trash fa-mini"></i>
									</a>
								</div>
							</td>
						</tr>
					<?php
					}
					?>
				</tbody>
				<tfooter>
					<tr>
						<th>NO</th>
						<th>NAMA ITEM / ID</th>
						<th>LOKER</th>
						<th>STATUS</th>
						<th></th>
					</tr>
				</tfooter>
			</table>
			<br>
		</div>
	</div>
</body>
<br><br>