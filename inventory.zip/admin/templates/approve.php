<?php
include("../connect.php");
?>

<head>
</head>

<body>
    <?php
    date_default_timezone_set('Asia/Jakarta');
    $datetime = date('Y-m-d H:i:s');

    if (isset($_SESSION['username']) && isset($_GET['trns']) && isset($_GET['id']) && isset($_GET['n'])) {
        $transaksi = $_GET['trns'];

        // GET ID ITEM
        $item_id = $_GET['id'];
        $result = mysqli_query($connect, "SELECT * FROM dataitem WHERE id='$item_id'");
        $row = mysqli_fetch_array($result);
        $nama_item = $row["namaitem"];
        $loker = $row["loker"];
        $nama_id = $nama_item . " [" . $item_id . " ]";
        //--------------------------------

        // OPEN LOKER
        $sql = "UPDATE loker SET value='open' WHERE variabel='$loker'";
        if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        //---------------------------------------------------

        // GET ID FINGERPRINT
        $sql_a = mysqli_query($connect, "SELECT * FROM receivedata WHERE variabel='finger'");
        $row_a = mysqli_fetch_array($sql_a);
        $id = $row_a["value"];
        //---------------------

        // CEK ANGGOTA
        $peminjam = $_GET['n'];

        $sql_b = mysqli_query($connect, "SELECT * FROM dataanggota WHERE id='$id'");
        $row_b = mysqli_fetch_array($sql_b);
        $cek_id = $row_b["id"];
        $peminjam_db = $row_b["nama"];
        $status_anggota = $row_b["status"];

        if ($status_anggota == "Staf") {
            $row_staf = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM serahterima WHERE variabel='Staf'"));
            $cek_a = $row_staf["value"];
            if ($cek_a == '') $sql = "INSERT into serahterima (variabel, value) VALUES ('Staf', '$id')";
            else $sql = "UPDATE serahterima SET value='$id' WHERE variabel='Staf'";
            if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        }

        $sql = mysqli_query($connect, "SELECT * FROM serahterima WHERE variabel='Staf'");
        $row = mysqli_fetch_array($sql);
        $cek_staf = $row["value"];

        $sql = mysqli_query($connect, "SELECT * FROM dataanggota WHERE id='$cek_staf'");
        $row_a = mysqli_fetch_array($sql);
        $nama_staf = $row_a["nama"];

        if ($status_anggota == "Umum" && $peminjam_db == $peminjam) {
            $row_umum = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM serahterima WHERE variabel='Umum'"));
            $cek_b = $row_umum["value"];
            if ($cek_b == '') $sql = "INSERT into serahterima (variabel, value) VALUES ('Umum', '$id')";
            else $sql = "UPDATE serahterima SET value='$id' WHERE variabel='Umum'";
            if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        }

        $sql = mysqli_query($connect, "SELECT * FROM serahterima WHERE variabel='Umum'");
        $row = mysqli_fetch_array($sql);
        $cek_peminjam = $row["value"];

        $sql = mysqli_query($connect, "SELECT * FROM dataanggota WHERE id='$cek_peminjam'");
        $row_b = mysqli_fetch_array($sql);
        $nama_peminjam = $row_b["nama"];

        // Refresh if id null
        if ($cek_staf > 0 && $cek_peminjam > 0) $cycle_cek = true;
        else $cycle_cek = false;

        if ($cycle_cek == false) {
            $url = $_SERVER['REQUEST_URI'];
            echo '<META HTTP-EQUIV="Refresh" Content="3"; URL="$url">';
        }
        //---------------------------------
    ?>
        <div class="container">
            <center>
                <br><br><br>
                <h2>SERAH TERIMA</h2>
                <br>
                <h6>SILAHKAN SCAN JARI</h6>
                <br><br>
            </center>

            <form action="" method="post">
                <div class="form-group">
                    <label name="item">Item</label>
                    <input autocomplete="off" class="form-control" placeholder="Item" type="text" name="item" value="<?php echo $nama_id; ?>" readonly required>
                    <br>
                    <label name="item">Loker</label>
                    <input autocomplete="off" class="form-control" placeholder="Loker" type="text" name="loker" value="<?php echo $loker; ?>" readonly required>

                    <br>
                    <label name="namastaf">Staff</label>
                    <input autocomplete="off" class="form-control" placeholder="-" type="text" name="namastaf" value="<?php echo $nama_staf; ?>" readonly required>

                    <br>
                    <label name="namaanggota">Peminjam</label>
                    <input autocomplete="off" class="form-control" placeholder="-" type="text" name="namaanggota" value="<?php echo $nama_peminjam; ?>" readonly required>
                </div>
                <?php
                if ($cek_staf > 0 && $cek_peminjam > 0) {
                ?>
                    <center>
                        <br><br>
                        <div>
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="">
                                SUBMIT
                            </button>
                        <?php
                    }
                        ?>
                        <br>
                        <button class="btn btn-success btn-block" type="button" <?php if ($transaksi == "pinjam") { ?> onclick="location='?p=pinjam'" <?php } else if ($transaksi == "kembali") { ?> onclick="location='?p=kembali'" <?php } ?>>
                            BATAL
                        </button>
                        </div>
                    </center>
            </form>
        </div>

    <?php
        if ($transaksi == "pinjam") $result = mysqli_query($connect, "SELECT * FROM datapinjam ORDER BY no DESC");
        else if ($transaksi == "kembali") $result = mysqli_query($connect, "SELECT * FROM datakembali ORDER BY no DESC");
        $row = mysqli_fetch_array($result);
        $last_no = $row["no"];

        if (isset($_POST['submit'])) {
            $last_no++;
            $Item = $_POST['item'];
            $Loker = $_POST['loker'];
            $Anggota = $_POST['namaanggota'];
            $Staf = $_POST['namastaf'];

            if ($transaksi == "pinjam") $sql = mysqli_query($connect, "INSERT INTO datapinjam (no, namaitem, loker, namaanggota, namastaf, status, datetime) VALUES ('$last_no', '$Item', '$Loker', '$Anggota', '$Staf', 'Belum', '{$datetime}')");
            else if ($transaksi == "kembali") $sql = mysqli_query($connect, "INSERT INTO datakembali (no, namaitem, loker, namaanggota, namastaf, datetime) VALUES ('$last_no', '$Item', '$Loker', '$Anggota', '$Staf', '{$datetime}')");

            if ($sql) {
                if (mysqli_query($connect, "DELETE FROM transaksi WHERE iditem='$item_id'")) {
                    if ($transaksi == "pinjam") {
                        echo "<script>alert('Berhasil..');location='?p=pinjam'</script>";
                        mysqli_query($connect, "UPDATE dataitem SET status='Dipinjam' WHERE id='$item_id'");
                    } else if ($transaksi == "kembali") {
                        echo "<script>alert('Berhasil..');location='?p=kembali'</script>";
                        mysqli_query($connect, "UPDATE datapinjam SET status='Sudah' WHERE namaitem='$nama_id'");
                        mysqli_query($connect, "UPDATE dataitem SET status='Tersedia' WHERE id='$item_id'");
                    }
                    // if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);

                    mysqli_query($connect, "UPDATE serahterima SET value='-' WHERE variabel='Staf'");
                    mysqli_query($connect, "UPDATE serahterima SET value='-' WHERE variabel='Umum'");

                    // MENGUNCI LOKER
                    mysqli_query($connect, "UPDATE loker SET value='lock' WHERE variabel='$loker'");
                    //---------------------------------------------------
                }
            } else {
                echo "<script>alert('Gagal! Coba lagi..');</script>";
                // if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
            }
        }
    }
    ?>
</body>
<center>
    <br><br>