<?php
include("../connect.php");
?>

<?php
date_default_timezone_set('Asia/Jakarta');
$datetime = date('Y-m-d H:i:s');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $result = mysqli_query($connect, "SELECT * FROM dataanggota WHERE id=$id");
    $data = mysqli_fetch_array($result);
    $nama = $data["nama"];
?>
    <div class="container">
        <br><br><br>
        <center>
            <h2>EDIT ANGGOTA</h2>
        </center>
        <br>

        <form action="" method="post">
            <div class="form-group">
                <label name="username">Nama</label>
                <input autocomplete="off" class="form-control" placeholder="Isi Nama" type="text" name="nama" value="<?php echo $nama; ?>" required>
            </div>

            <br><br>
            <center>
                <div>
                    <button class="btn btn-primary btn-block" type="submit" name="submit">
                        SIMPAN
                    </button>

                    <br>
                    <button class="btn btn-warning btn-block" type="button" onclick="location='?p=dataanggota'">
                        BATAL
                    </button>
                </div>
            </center>
        </form>
    </div>

<?php
    if (isset($_POST['submit'])) {
        $Nama = $_POST['nama'];

        $sql = mysqli_query($connect, "UPDATE dataanggota SET nama='$Nama', datetime='$datetime' WHERE id='$id'");
        if ($sql) {
            echo "<script> location='?p=dataanggota'</script>";
            $sql = "UPDATE receivedata SET status='-' WHERE value='-'";
            if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        } else {
            echo "<script>alert('Gagal mengedit data!');</script>";
            $sql = "UPDATE receivedata SET status='-' WHERE value='-'";
            if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        }
    }
}
?>
<br> <br> <br>