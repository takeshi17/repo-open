<?php
include('connect.php');
$url = $_SERVER['REQUEST_URI'];
echo '<META HTTP-EQUIV="Refresh" Content="3"; URL="$url">';
?>

<?php
if (isset($_GET['p'])) {
    $p = $_GET['p'];
} else $p = 1;

if (isset($_GET['n'])) {
    $Select_nama = $_GET['n'];
    $Select_id = $_GET['id'];
    $ID = rawurldecode($Select_id);
    $Nama = rawurldecode($Select_nama);
}

mysqli_query($connect, "DELETE from rfid WHERE no='1'");

// function is_connected(){
//     $connected = @fsockopen("www.google.com", 80);
//     //website, port  (try 80 or 443)
//     if ($connected) {
//         $is_conn = true; //saat konek
//         fclose($connected);
//     } else {
//         $is_conn = false; //tidak ada koneksi
//     }
//     return $is_conn;
// }

$dataperPage = 10;
$offset = ($p - 1) * $dataperPage;

$sql_a = mysqli_query($connect, "SELECT count('No') AS totaldata FROM datatransaksi WHERE id = '$ID'");
$x = mysqli_fetch_array($sql_a);
$total_data = $x['totaldata'];

$query = "SELECT * FROM datatransaksi WHERE id = '$ID' order by No DESC limit $offset, $dataperPage";
$sql_b = mysqli_query($connect, $query);
if (mysqli_num_rows($sql_b) > 0) {
    $jum_data = mysqli_num_rows($sql_b);
    $jumData = $offset + $jum_data;
?>

    <br><br><br>
    <h2 style="margin-top:10px;color:#666666;text-align:center;margin:20px;">Data Transaksi <?php echo $Nama; ?> (<?php echo $jumData . " / " . $total_data ?>)</h2>
    </div>

    <div class="container" style="overflow-y:none; overflow-x:none; min-height:270px">
        <div class="center">

            <h3>
                <table border="1" style="min-width:1150px" id="table">

                    </tr>
                </table>
            </h3>

            <div align="center" style="margin-top:30px;">

                <!-- <table border="1" style="min-width:1152px" id="table"> -->
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Waktu Transaksi</th>
                            <th>Transaksi</th>
                            <th>Sisa Saldo</th>
                            <th>Jenis Transaksi</th>
                            <!-- <th> </th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = ($p * $dataperPage) - ($dataperPage - 1);
                        $img = 0;
                        while ($data = mysqli_fetch_array($sql_b)) {
                        ?>
                            <tr>
                                <td><?php echo $no; ?></td>
                                <td><?php echo $data['datetime']; ?></td>
                                <td><?php echo "Rp " . number_format($data['transaksi'], 0, ",", "."); ?></td>
                                <td><?php echo "Rp " . number_format($data['saldo'], 0, ",", "."); ?></td>
                                <td><?php echo $data['jenis']; ?></td>
                                <!-- <td align="center">
                                    <a class="btn btn-danger btn-mini" href="hapusdata.php?data=anggota&no=<?php echo $data['no']; ?>&p=<?php echo $p; ?>">
                                        <i class="fa fa-trash fa-mini"></i>
                                    </a></td> -->
                            </tr>
                        <?php $no++;
                        } ?>
                    </tbody>
                </table>
                <br>
                <div class="text-right">
                    <a class="btn btn-primary btn-mini" href="exportexcel.php?data=transaksi&id=<?php echo $ID; ?>&n=<?php echo $Nama; ?>">
                        <i class="fa fa-plus-square fa-mini"> Export to Excel</i></a>
                </div>

                <?php
                //------------------------------------untuk membuat pagging------------------------------------------
                $jumlahPage = ceil($total_data / $dataperPage);

                $n = 1;
                $limitpage = 5;
                $np = ceil($jumlahPage / $limitpage);
                $tp = $np * $limitpage;
                $lp = $tp - $limitpage;

                if ($p > $limitpage) {
                    echo " <a href='?page=transaksi&p=1' class='btn btn-mini'>|<</a> ";
                }
                if ($p > 1) {
                    echo " <a href='?page=transaksi&id=$ID&n=$Nama&p=" . ($p - 1) . "' style='color:black' class='btn btn-default btn-mini'><<</a> ";
                } //prev button

                for ($i = 1; $i <= $np; $i++) {
                    if ($p > (($i - 1) * $limitpage)) {
                        $pg = (($limitpage * $i) - $limitpage) + 1;
                        $limit = $limitpage * $i;
                        if ($i == $np) {
                            $limit = $jumlahPage;
                        }
                    }
                }

                for ($n = $pg; $n <= $limit; $n++) {
                    if ($n == $p) {
                        echo " <b class='btn btn-mini btn-primary'>" . $n . "</b> ";
                    } else {
                        echo " <a href='?page=transaksi&id=$ID&n=$Nama&p=" . $n . "' class='btn btn-default btn-mini'>" . $n . "</a> ";
                    }
                }

                if ($p < $jumlahPage) {
                    echo " <a href='?page=transaksi&id=$ID&n=$Nama&p=" . ($p + 1) . "' style='color:black' class='btn btn-default btn-mini'>>></a> ";
                } //next button 
                if ($p < $lp) {
                    echo " <a href='?page=transaksi&id=$ID&n=$Nama&p=" . $jumlahPage . "' class='btn btn-primary btn-mini'>>|</a> ";
                }
                ?>
            </div>
        </div>

    <?php } else  echo "<br><br><br><section id='error' class='container text-center'> <h1> Belum ada Transaksi $Nama </h1> </section> "; ?>
    <br><br><br><br>