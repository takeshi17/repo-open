<?php
include("../connect.php");
?>

<?php

if (isset($_SESSION['username'])) {
?>
	<div class="container">
		<center>
			<br><br><br>
			<h2><b>SETTING<b></h2>
			<br><br>
		</center>

		<form action="" method="post">
			<div class="form-group">
				<center>
					<h3>LOKER</h3>
				</center>
				<?php
				$sql = mysqli_query($connect, "SELECT * FROM loker ORDER BY variabel ASC");
				if (mysqli_num_rows($sql) > 0) {
				?>
					<select id="edit" type="text" class="form-control" name="edit">
						<?php
						if (isset($_GET['l'])) {
							$loker = $_GET['l'];
							$status = $_GET['s'];
						?>
							<option value=<?php echo $loker; ?>>-- <?php echo $loker . "  [ " . $status . " ]"; ?> --</option>
							<?php
							while ($data = mysqli_fetch_array($sql)) {
								if ($loker != $data['variabel']) {
							?>
									<option value=<?php echo $data['variabel']; ?>><?php echo $data['variabel'] . "  [ " . $data['value'] . " ]"; ?></option>
								<?php
								}
							}
						} else {
							while ($data = mysqli_fetch_array($sql)) {
								?>
								<option value=<?php echo $data['variabel']; ?>><?php echo $data['variabel'] . "  [ " . $data['value'] . " ]"; ?></option>
						<?php
							}
						}
						?>

					</select>

					<div class="text-center" style="margin-top:10px">
						<div class="btn-group">
							<button class="btn btn-info btn-sm" type="submit" name="open"><i class="fa fa-unlock-alt"></i></button>
							<button class="btn btn-danger btn-sm" type="submit" name="hapus"><i class="fa fa-trash"></i></button>
							<button class="btn btn-warning btn-sm" type="submit" name="lock"><i class="fa fa-lock"></i></button>
						</div>
					</div>

					<input style="margin-top:15px" autocomplete="off" class="form-control" placeholder="Tambah Loker" type="text" name="add"></input>
					<button style="margin-top:10px" class="btn btn-primary btn-sm btn-block" type="submit" name="tambah"><i class="fa fa-plus-square"> Tambah</i></button>
				<?php
				} else {
				?>
					<br>
					<input autocomplete="off" class="form-control" placeholder="Tambah Loker" type="text" name="add"></input>
					<button style="margin-top:10px" class="btn btn-primary btn-sm" type="submit" name="tambah"><i class="fa fa-plus-square"> Tambah</i></button>
				<?php
				}
				?>
			</div>
			<!-- <div class="form-group" style="margin-top:50px">
				<center>
					<h3>JENIS ANGGOTA</h3>
				</center>
			</div> -->
		</form>
	</div>

<?php

	$result = mysqli_query($connect, "SELECT * FROM loker ORDER BY No DESC LIMIT 1");
	$row = mysqli_fetch_array($result);
	$last_no = $row["no"];

	if (isset($_POST['tambah'])) {
		$last_no++;
		$Loker = $_POST['add'];

		if ($Loker != "") {
			$result = mysqli_query($connect, "SELECT * FROM loker WHERE variabel='$Loker'");
			$row = mysqli_fetch_array($result);
			$Loker_db = $row["variabel"];

			if ($Loker_db == "") {
				$sql = mysqli_query($connect, "INSERT INTO loker (no, variabel, value) VALUES ('$last_no', '$Loker', 'lock')");
				if ($sql) {
					echo "<script>location='?p=setting'</script>";
				}
			} else {
				echo "<script>alert('Loker $Loker sudah ada');location='?p=setting'</script>";
			}
		}
	} else if (isset($_POST['hapus'])) {
		$Loker = $_POST['edit'];

		if (mysqli_query($connect, "DELETE FROM loker WHERE variabel='$Loker'")) {
			echo "<script>location='?p=setting'</script>";
		}
	} else if (isset($_POST['open'])) {
		$Loker = $_POST['edit'];
		if (mysqli_query($connect, "UPDATE loker SET value='open' WHERE variabel='$Loker'")) {
			echo "<script>location='?p=setting&l=$Loker&s=open'</script>";
		}
	} else if (isset($_POST['lock'])) {
		$Loker = $_POST['edit'];

		if (mysqli_query($connect, "UPDATE loker SET value='lock' WHERE variabel='$Loker'")) {
			echo "<script>location='?p=setting&l=$Loker&s=lock'</script>";
		}
	}
}
?>