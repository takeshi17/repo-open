<div class="container">
	<br><br><br>
	<center>
		<h2>UBAH AKUN ADMIN</h2>
	</center>
	<br>

	<form action="" method="post">
		<div class="form-group">
			<label name="username">Username lama</label>
			<input autocomplete="off" class="form-control" placeholder="" type="text" name="username" required>
		</div>

		<div class="form-group">
			<label name="password">Password lama</label>
			<input autocomplete="off" class="form-control" placeholder="" type="password" name="password" required>
		</div>

		<div class="form-group">
			<label name="newusername">Username baru</label>
			<input autocomplete="off" class="form-control" placeholder="" type="text" name="newusername" required>
		</div>

		<div class="form-group">
			<label name="newpassword">Password baru</label>
			<input autocomplete="off" class="form-control" placeholder="" type="password" name="newpassword" required>
		</div>

		<br /><br />
		<center>
			<div>
				<button class="btn btn-primary btn-block" type="submit" name="submit" value="">
					SIMPAN
				</button>
			</div>
		</center>
		<br>

		<center>
			<div>
				<button class="btn btn-success btn-block" type="button" onclick="window.history.back()">
					BATAL
				</button>
			</div>
	</form>
	</center>
</div>

<?php
include "../connect.php";

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$newusername = $_POST['newusername'];
	$password = md5($_POST['password']);
	$newpassword = md5($_POST['newpassword']);

	if ($username == $_SESSION['username'] && $password == $_SESSION['password']) {
		$query = "UPDATE admin set username = '$newusername', password = '$newpassword'";
		$sql = mysqli_query($connect, $query);
		if ($sql) {
			echo "<script>alert('Akun admin berhasil di update!');location='../logout.php'</script>";
		} 
	} else {
		echo "<script>alert('Gagal mengganti akun admin!')location='../index.php'</script>";
	}
}
?>
<br><br>