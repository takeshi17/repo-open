<?php
include("../connect.php");
?>

<?php
date_default_timezone_set('Asia/Jakarta');
$datetime = date('Y-m-d H:i:s');

if (isset($_GET['p'])) {
    $p = $_GET['p'];
} else $p = 1;

$items = $_GET['items'];
$loker = $_GET['loker'];

$result = mysqli_query($connect, "SELECT * FROM receivedata WHERE variabel='items'");
$row = mysqli_fetch_array($result);
$id = $row["value"];
$status = $row["status"];

if ($id != "-" && $status != "already") $cycle_cek = true;
else $cycle_cek = false;

if ($cycle_cek == false) {
    $url = $_SERVER['REQUEST_URI'];
    echo '<META HTTP-EQUIV="Refresh" Content="3"; URL="$url">';
}

if ($id == "") $sql = "INSERT into receivedata (variabel, value, mode, status) VALUES ('items', '-', 'enroll', '-')";
else $sql = "UPDATE receivedata SET value='-', mode='enroll', status='-' WHERE variabel='items'";

if (!mysqli_query($connect, $sql)) {
    echo "Error: " . $sql . "<br>" . mysqli_error($connect);
}

if (isset($_SESSION['username'])) {
?>
    <div class="container">
        <br><br><br>
        <center>
            <h2>TAMBAH ITEM</h2>
        </center>
        <br>

        <center>
            <h6>SILAHKAN SCAN</h6>
            <button class="btn btn-default btn-md" type="button" onclick="<?php
                                                                            $sql = "UPDATE receivedata SET value='-' WHERE variabel='items'";
                                                                            if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
                                                                            ?> location.reload();">
                RESET
            </button>
        </center>
        <br><br>

        <form action="" method="post">
            <div class="form-group">
                <label name="id">ID</label>
                <input autocomplete="off" class="form-control" placeholder="ID" type="text" name="id" value="<?php if ($id != "-") {
                                                                                                                    if ($status != "already") echo $id;
                                                                                                                    else echo "ID Already use";
                                                                                                                } else echo "ID"; ?>" readonly required>

                <br>
                <label name="username">Nama Item</label>
                <input autocomplete="off" class="form-control" placeholder="Isi Nama Item" type="text" name="itemname" value="<?php echo $items; ?>" required>

                <br>
                <label name="loker">Loker</label>
                <?php
                $sql = mysqli_query($connect, "SELECT * FROM loker ORDER BY variabel ASC");
                if (mysqli_num_rows($sql) > 0) {
                ?>
                    <select id="loker" type="text" class="form-control" name="loker" required>
                        <?php
                        while ($data = mysqli_fetch_array($sql)) {
                        ?>
                            <option value=<?php echo $data['variabel']; ?>><?php echo $data['variabel']; ?></option>
                    <?php
                        }
                    }
                    ?>
                    </select>
            </div>

            <?php
            if ($id != "-" && $id != "" && $status != "already") {
            ?>
                <br><br>
                <center>
                    <div>
                        <button class="btn btn-primary btn-block" type="submit" name="submit" value="">
                            TAMBAHKAN
                        </button>
                        <br>
                        <button class="btn btn-success btn-block" type="button" onclick="location='?p=dataitem'">
                            BATAL
                        </button>
                    <?php
                } else {
                    ?>
                        <br>
                        <button class="btn btn-success btn-block" type="button" onclick="location='?p=dataitem'">
                            SELESAI
                        </button>
                    </div>
                </center>
            <?php
                }
            ?>
        </form>
    </div>

<?php
    $result = mysqli_query($connect, "SELECT * FROM dataitem ORDER BY No DESC LIMIT 1");
    $row = mysqli_fetch_array($result);
    $last_no = $row["no"];

    if (isset($_POST['submit'])) {
        $last_no++;
        $ID = $_POST['id'];
        $Items = $_POST['itemname'];
        $Loker = $_POST['loker'];

        // $result = mysqli_query($connect, "SELECT * FROM dataitem WHERE namaitem='$Items' and loker='$Loker'");
        // $row = mysqli_fetch_array($result);
        // $jumlah = $row["jumlahtotal"];
        // $tambah = $jumlah + 1;   

        // $sql_a = mysqli_query($connect, "UPDATE dataitem SET jumlahtotal='$tambah' WHERE namaitem='$Items' and loker='$Loker'");
        $sql = mysqli_query($connect, "INSERT INTO `dataitem` (no, id, namaitem, loker, status) VALUES ('$last_no','$ID', '$Items', '$Loker', 'Tersedia')");
        if ($sql) {
            echo "<script>alert('Berhasil menambah $Items');location='?p=tambahitem&items=" . $Items . "&loker=" . $Loker . "&p=" . $p . "'</script>";
            $sql_a = "UPDATE receivedata SET value='-' WHERE variabel='items'";
            if (!mysqli_query($connect, $sql_a)) echo "Error: " . $sql_a . "<br>" . mysqli_error($connect);
        } else {
            echo "<script>alert('Gagal menambah item!');'</script>";
            $sql_a = "UPDATE receivedata SET value='-' WHERE variabel='items'";
            if (!mysqli_query($connect, $sql_a)) echo "Error: " . $sql_a . "<br>" . mysqli_error($connect);
        }
    }
}
?>
<br><br>