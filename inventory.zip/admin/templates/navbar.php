<?php if (isset($_SESSION['username']) && isset($_SESSION['password'])) { ?>
    <nav class="navbar-fixed-top navbar-inverse">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="#"><b>INVENTORY MANAGEMENT</b></a>
            </div>
                <!-- <span class="navbar-text" style="font-size:14px">Halaman Admin</span> -->

            <ul class="nav navbar-nav navbar-right">
                <ul class="nav navbar-nav">
                    <li class=""><a href="../">Home</a></li>
                    <li class="dropdown">
                        <a href="#">Transaksi <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li> <a href="?p=pinjam"><span style="font-size:15px"></span> Peminjaman</a></li>
                            <li> <a href="?p=kembali"><span style="font-size:15px"></span> Pengembalian</a></li>
                        </ul>
                    </li>
                    <li><a href="?p=dataanggota">Anggota</a></li>
                    <li><a href="?p=dataitem">Item</a></li>
                    <li><a href="?p=setting">Setting</a></li>
                </ul>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="#"><span style="font-size:15px"><span class="fa fa-user-circle"></span>
                            <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li> <a href="?p=updateadmin"><span style="font-size:15px"></span> Ubah Akun</a></li>
                        <li> <a href="?p=logout"><span style="font-size:15px"></span> Logout</a></li>
                    </ul>
            </ul>
            </li>
        <?php } else {
    } ?>
        </div>
    </nav>