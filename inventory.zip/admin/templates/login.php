<div class="container">
    <br><br><br>
    <center>
        <h1>LOGIN ADMIN</h1?>
    </center>

    <form action="" method="post">
        <div class="input-group" style="margin-top:50px">
            <span class="input-group-addon"><i class="fa fa-user"></i></span>
            <input autocomplete="off" class="form-control" placeholder="Username" type="text" name="username" required>
        </div>
        <div class="input-group" style="margin-top:15px">
            <span class="input-group-addon"><i class="fa fa-lock"></i></span>
            <input autocomplete="off" class="form-control" placeholder="Password" type="password" name="password" required>
        </div>

        <br><br>
        <center>
            <div class="form-group">
                <button class="btn btn-primary btn-block" type="submit" name="submit">
                    LOGIN
                </button>
                <br>
                <button class="btn btn-success btn-block" type="button" onclick="window.history.back()">
                    KEMBALI
                </button>
            </div>
        </center>
    </form>
</div>

<?php
include("../connect.php");

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $sql = mysqli_query($connect, "SELECT * FROM admin WHERE username = '$username' && password = '$password'");
    if (mysqli_num_rows($sql) > 0) {
        $data = mysqli_fetch_array($sql);
        $_SESSION['username'] = $data['username'];
        $_SESSION['password'] = $data['password'];
        header("location:?page=pinjam");
    } else {
        echo "<script>alert('Login gagal');</script>";
    }
}
?>