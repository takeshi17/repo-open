<?php
include('../connect.php');
// fungsi header dengan mengirimkan raw data excel
header("Content-type: application/vnd-ms-excel");

if (isset($_GET['data'])) {
	$data = $_GET['data'];
	if (!empty($data)) {
		if ($data == 'anggota') {
			// membuat nama file ekspor
			header("Content-Disposition: attachment; filename=data-anggota.xls");
?>
			<div align="center" style="margin-top:10px;">
				<h2>
					<td align="center">DATA ANGGOTA</td>
				</h2>
				<table border="1" style="min-width:1152px" id="table">
					<thead>
						<tr>
							<th>NO</th>
							<th>NAMA</th>
							<th>STATUS</th>
							<th>TRANSAKSI TERAKHIR</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$no = 0;
						$sql = mysqli_query($connect, "SELECT * FROM dataanggota");
						while ($data = mysqli_fetch_array($sql)) {
							$no++;
						?>
							<tr>
								<td><?php echo $no; ?></td>
								<td><?php echo $data['nama']; ?></td>
								<td><?php echo $data['status']; ?></td>
								<td><?php echo $data['datetime']; ?></td>
							</tr>
						<?php
						}
						?>
					</tbody>
				</table>
			</div>
		<?php
		} else if ($data == 'items') {
			// membuat nama file ekspor
			header("Content-Disposition: attachment; filename=data-item.xls");
		?>
			<div align="center" style="margin-top:10px;">
				<h2>
					<td align="center">DATA ITEM</td>
				</h2>
				<table border="1" style="min-width:1152px" id="table">
					<thead>
						<tr>
							<th>NO</th>
							<th>NAMA ITEM / ID</th>
							<th>LOKER</th>
							<th>STATUS</th>
						</tr>
					</thead>
					<tbody">
						<?php
						$no = 0;
						$sql = mysqli_query($connect, "SELECT * FROM dataitem");
						while ($data = mysqli_fetch_array($sql)) {
							$no++;
							$id = $data['id'];
							$nama_item = $data['namaitem'];
							$loker = $data['loker'];
							$status = $data['status'];
							$nama_id = $nama_item . " [" . $id . " ]";
						?>
							<tr>
								<td><?php echo $no; ?></td>
								<td><?php echo $nama_item . " [" . $id . " ]"; ?></td>
								<td><?php echo $loker; ?></td>
								<td><?php echo $status; ?></td>
							</tr>
						<?php
						}
						?>
						</tbody>
				</table>
			</div>
		<?php
		} else if ($data == 'pinjam') {
			// membuat nama file ekspor
			header("Content-Disposition: attachment; filename=data-transaksi-peminjaman.xls");
		?>
			<div align="center" style="margin-top:10px;">
				<h2>
					<td align="center">DATA TRANSAKSI PEMINJAMAN</td>
				</h2>
				<table border="1" style="min-width:1152px" id="table">
					<thead>
						<tr">
							<th>NO</th>
							<th>NAMA ITEM / ID</th>
							<th>LOKER</th>
							<th>NAMA PEMINJAM</th>
							<th>NAMA STAF</th>
							<th>DIKEMBALIKAN</th>
							<th>WAKTU TRANSAKSI</th>
							</tr>
					</thead>
					<tbody>
						<?php
						$no = 0;
						$sql = mysqli_query($connect, "SELECT * FROM datapinjam ORDER BY no ASC");
						while ($data = mysqli_fetch_array($sql)) {
							$no++;
						?>
							<tr>
								<td><?php echo $no; ?></td>
								<td><?php echo $data['namaitem']; ?></td>
								<td><?php echo $data['loker']; ?></td>
								<td><?php echo $data['namaanggota']; ?></td>
								<td><?php echo $data['namastaf']; ?></td>
								<td><?php echo $data['status']; ?></td>
								<td><?php echo $data['datetime']; ?></td>
							</tr>
						<?php
						}
						?>
					</tbody>
				</table>
			</div>
		<?php
		} else if ($data == 'kembali') {
			header("Content-Disposition: attachment; filename=data-transaksi-pengembalian.xls");
		?>
			<div align="center" style="margin-top:30px;">
				<h2>
					<td align="center">DATA TRANSAKSI PENGEMBALIAN</td>
				</h2>
				<table border="1" style="min-width:1152px" id="table">
					<thead>
						<tr>
							<th>NO</th>
							<th>NAMA ITEM / ID</th>
							<th>LOKER</th>
							<th>NAMA PEMINJAM</th>
							<th>NAMA STAF</th>
							<th>WAKTU TRANSAKSI</th>
							<!-- <th></th> -->
						</tr>
					</thead>
					<?php
					$no = 0;
					$sql = mysqli_query($connect, "SELECT * FROM datakembali ORDER BY no ASC");
					while ($data = mysqli_fetch_array($sql)) {
						$no++;
					?>
						<tr>
							<td><?php echo $no; ?></td>
							<td><?php echo $data['namaitem']; ?></td>
							<td><?php echo $data['loker']; ?></td>
							<td><?php echo $data['namaanggota']; ?></td>
							<td><?php echo $data['namastaf']; ?></td>
							<td><?php echo $data['datetime']; ?></td>
						</tr>
					<?php
					}
					?>
					</tbody>
				</table>
			</div>
<?php
		}
	}
}
?>