<?php
ob_start();
session_start();
if(isset($_SESSION['username']) && isset($_SESSION['password'])){
	unset($_SESSION['username']);
	unset($_SESSION['password']);
	unset($_SESSION['nama']);
	header('location:../');
}
ob_end_flush();
?>