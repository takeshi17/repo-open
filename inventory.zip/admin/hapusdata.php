<?php
include("../connect.php");

if (isset($_GET['data']) && isset($_GET['id'])) {
	$data = $_GET['data'];

	$Select_id = $_GET['id'];
	$ID = rawurldecode($Select_id);

	if (!empty($data)) {
		if ($data == 'item') {
			if (mysqli_query($connect, "DELETE FROM dataitem WHERE id='$ID'")) {
				header("Location: index.php?p=dataitem");
			}
		} else if ($data == 'anggota') {
			if (mysqli_query($connect, "DELETE FROM dataanggota WHERE id='$ID'")) {
				header("Location: index.php?p=dataanggota");
			}
		} else if ($data == 'pinjam' || $data == 'kembali') {
			if (mysqli_query($connect, "DELETE FROM transaksi WHERE iditem='$ID'")) {
				if (!mysqli_query($connect, "UPDATE dataitem SET status='Tersedia' WHERE id='$ID'")) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
				else {
					if($data == 'pinjam') header("Location: index.php?p=pinjam");
					else header("Location: index.php?p=kembali");
				}
			}
		}
	}
}


// Kosongkan data
// else {
//     mysqli_query($connect, "TRUNCATE energy_monitoring");
// 	header ("Location: index.php?page=data_daya&p=0");
// }

// Hapus
// else if(isset($_GET['total'])){
// 	$totaldata = $_GET['total'];

// 	for($i=0;$i<$totaldata;$i++){
// 		mysqli_query($connect, "DELETE FROM energy_monitoring WHERE no=$i");
// 	}

// 	if($i == $totaldata){
// 		header ("Location: index.php?page=data_daya");
// 	}
// }
