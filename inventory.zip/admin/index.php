<?php
ob_start();
session_start();
include "../connect.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Inventory Management</title>

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" type="text/css" href="../assets/css/animate.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/responsive.css">
	<link rel="stylesheet" type="text/css" href="../assets/bootstrap-3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/data-tables/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
	<!-- <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->

	<!-- jQuery library -->
	<script type="text/javascript" src="../assets/jquery/jquery.min.js"></script> <!-- V 3.4.1 -->
	<!-- Latest compiled JavaScript -->
	<script type="text/javascript" src="../assets/bootstrap-3.4.1/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../assets/data-tables/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="../assets/data-tables/js/dataTables.bootstrap.min.js"></script>

	<!-- JavaScript datatables -->
	<script>
		$(document).ready(function() {
			$("#table_id").DataTable({
				// "columnDefs": [{
				// 	"targets": [4],
				// 	"searchable": false,
				// }],
				"lengthMenu": [
					[10, 25, 50, -1],
					[10, 25, 50, "All"]
				],
				"pagingType": "simple_numbers"
			});
			$('.dataTables_length').addClass('bs-select');
		});
	</script>

</head>

<body>
	<?php

	//untuk konten header --------------------
	include('templates/navbar.php');
	// include "templates/header.php";
	//untuk konten utama ---------------------
	if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
		if (isset($_GET['p'])) {
			$page = $_GET['p'];
			if (!empty($page)) {

				if ($page != 'tambahanggota' && $page != 'approve') {
					$result = mysqli_query($connect, "SELECT * FROM receivedata WHERE variabel='finger'");
					$row = mysqli_fetch_array($result);
					$cek = $row["value"];

					if ($cek == '') $sql = "INSERT into receivedata (variabel, value, mode, status) VALUES ('finger', '-', 'scan', '-')";
					else $sql = "UPDATE receivedata SET value='-', mode='scan', status='-' WHERE variabel='finger'";

					if (!mysqli_query($connect, $sql)) echo "Error: " . $sql . "<br>" . mysqli_error($connect);

					if (!mysqli_query($connect, "UPDATE serahterima SET value='-' WHERE variabel='Staf'")) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
					if (!mysqli_query($connect, "UPDATE serahterima SET value='-' WHERE variabel='Umum'")) echo "Error: " . $sql . "<br>" . mysqli_error($connect);
				}

				if ($page != 'tambahitem') {
					$result = mysqli_query($connect, "SELECT * FROM receivedata WHERE variabel='items'");
					$row = mysqli_fetch_array($result);
					$cek = $row["value"];

					if ($cek == "") $sql = "INSERT into receivedata (variabel, value, status) VALUES ('items', '-', 'scan', '-')";
					else $sql = "UPDATE receivedata SET value='-', mode='scan', status='-' WHERE variabel='items'";

					if (!mysqli_query($connect, $sql)) {
						echo "Error: " . $sql . "<br>" . mysqli_error($connect);
					}
				}

				if ($page == 'dataanggota')        include('templates/dataanggota.php');
				else if ($page == 'tambahanggota') include('templates/tambahanggota.php');
				else if ($page == 'editanggota')   include('templates/editanggota.php');
				else if ($page == 'dataitem')      include('templates/dataitem.php');
				else if ($page == 'tambahitem')    include('templates/tambahitem.php');
				else if ($page == 'edititem')      include('templates/edititem.php');
				else if ($page == 'hapusdata')     include('templates/edititem.php');
				else if ($page == 'pinjam') 	   include('templates/datapeminjaman.php');
				else if ($page == 'approve')       include('templates/approve.php');
				else if ($page == 'kembali')	   include('templates/datakembali.php');
				else if ($page == 'setting') 	   include('templates/setting.php');
				else if ($page == 'updateadmin')   include('templates/updateadmin.php');
				else if ($page == 'logout') 	   include('logout.php');
				else include('../templates/404.php');
			} else include('../templates/404.php');
		} else header('location: ?p=pinjam');
	} else include('templates/login.php');
	?>
</body>

</html>
<?php ob_end_flush(); ?>